#!/usr/bin/env python3
"""Compile the isolated opening API probe against both frozen candidates."""
from pathlib import Path
import concurrent.futures
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("run_candidates", ROOT / "run_candidates.py")
runtime = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runtime)
PROBE = ROOT / "proofs/openings/opening-api-probe.tex"


def build(design, profile):
    src = runtime.source(design)
    out = ROOT / "proofs/openings" / design
    out.mkdir(parents=True, exist_ok=True)
    job = "opening-api-" + profile
    env = runtime.environment(src)
    env["TEXINPUTS"] = str(src) + "//:"
    tex = (r"\def\ProbePrint{1}" if profile == "PRINT" else "") + r"\input{" + str(PROBE) + "}"
    commands = []
    for run in (1, 2):
        log = out / (job + ".pass" + str(run) + ".stdout")
        with log.open("w") as output:
            result = subprocess.run(
                ["xelatex", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
                 "-output-directory=" + str(out), "-jobname=" + job, tex],
                cwd=src, env=env, stdout=output, stderr=subprocess.STDOUT)
        commands.append({"run": run, "returncode": result.returncode, "stdout": str(log)})
        if result.returncode:
            break
    return {"design": design, "profile": profile, "commands": commands,
            "pdf": str(out / (job + ".pdf")), "log": str(out / (job + ".log")),
            "status": "passed" if all(x["returncode"] == 0 for x in commands) and len(commands) == 2 else "failed"}


if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(build, design, profile)
                   for design in ("REFINED", "MINIMAL") for profile in ("SCREEN", "PRINT")]
        rows = [future.result() for future in futures]
    (ROOT / "proofs/openings/BUILD_RESULTS.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))
    sys.exit(0 if all(row["status"] == "passed" for row in rows) else 1)
