#!/usr/bin/env python3
"""Bind final opening/API checks and preview panels to their actual input hashes."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys

import fitz
from PIL import Image, ImageDraw, ImageFont

sys.dont_write_bytecode = True
D = Path(__file__).resolve().parent
R = D.parents[1]
BP_PER_PT = 72 / 72.27
MM_PER_BP = 25.4 / 72
TITLE_BP = 17.5 * BP_PER_PT
EXPECTED_HELPER = 'd42a60c89940c57836664319ee573a85d87b534c9fe5f5aa839030fec5e3b0b4'
EXPECT = json.loads((D / 'opening-probe-expectations.json').read_text())
DESIGNS = ('REFINED', 'MINIMAL')
PROFILES = ('SCREEN', 'PRINT')
PAIRS = {
    'long-opening-body': (1, 2),
    'no-photo': (5, 6),
    'callout': (9, 10),
    'paragraph-native': (8, 11),
    'next-and-paragraph-opening': (3, 7),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rel(path):
    return str(path.relative_to(R))


def norm(text):
    text = text.replace('∆', 'Δ')
    text = re.sub(r'-\s*\n\s*', '', text)
    return ' '.join(text.split())


def spans(page):
    return [s for b in page.get_text('dict')['blocks']
            for line in b.get('lines', []) for s in line['spans']]


def title_spans(page):
    return [s for s in spans(page) if abs(s['size'] - TITLE_BP) < .001]


def log_evidence(path):
    content = path.read_text(errors='replace')
    warnings = [line for line in content.splitlines() if 'Warning:' in line]
    counts = {
        'overfull': len(re.findall(r'Overfull \\[hv]box', content)),
        'underfull': len(re.findall(r'Underfull \\[hv]box', content)),
        'missing_characters': content.count('Missing character:'),
        'undefined_references': len(re.findall(r'(?:Reference .* undefined|There were undefined references)', content)),
        'rerun_needed': len(re.findall(r'(?:Rerun to get|Label\(s\) may have changed|Rerun LaTeX|Please \(re\)run)', content)),
        'errors': len(re.findall(r'(?:^!|(?:LaTeX|Package [^\n]+) Error:)', content, re.M)),
        'warnings': len(warnings),
    }
    expected = [r'Package caption Warning: Unused \captionsetup[figure]',
                r'Package caption Warning: Unused \captionsetup[table]']
    return {'path': rel(path), 'sha256': sha(path), 'counts': counts,
            'warning_lines': warnings,
            'only_expected_unused_caption_warnings': len(warnings) == 2 and all(
                any(line.startswith(prefix) for prefix in expected) for line in warnings)}


def fonts_evidence(doc):
    result = []
    for xref in sorted({f[0] for page in doc for f in page.get_fonts(full=True)}):
        name, ext, kind, data = doc.extract_font(xref)
        result.append({'font': name, 'format': ext, 'type': kind, 'embedded_bytes': len(data)})
    return result


def panel(doc, design, profile, name, pages):
    pixmaps = [doc[n-1].get_pixmap(dpi=120, alpha=False) for n in pages]
    images = [Image.frombytes('RGB', (p.width, p.height), p.samples) for p in pixmaps]
    gutter, label_h = 24, 38
    canvas = Image.new('RGB', (sum(im.width for im in images) + gutter,
                               max(im.height for im in images) + label_h), '#e8e8e8')
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 16)
    x = 0
    for im, page in zip(images, pages):
        canvas.paste(im, (x, label_h))
        draw.text((x+12, 9), f'{design} / {profile} — page {page}', fill='#222222', font=font)
        x += im.width + gutter
    path = D / f'{design}_{profile}_{name}.png'
    canvas.save(path)
    return {'path': rel(path), 'sha256': sha(path),
            'source_pdf_sha256': sha(Path(doc.name)),
            'source_pages': list(pages), 'pixel_dimensions': list(canvas.size), 'dpi': 120}


def opening_evidence(design, profile):
    path = D / design / f'opening-api-{profile}.pdf'
    doc = fitz.open(path)
    texts = [norm(page.get_text()) for page in doc]
    dims = [[round(page.rect.width*MM_PER_BP, 5), round(page.rect.height*MM_PER_BP, 5)] for page in doc]
    cases = []
    for expected in EXPECT['opening_cases']:
        chapter, opn, body = expected['chapter'], expected['opening_page'], expected['body_page']
        opening, first = doc[opn-1], doc[body-1]
        large = [s for s in spans(opening) if s['size'] > 20 and 'NotoSerif' in s['font']]
        title = title_spans(first)
        label = [s for s in spans(first) if s['text'] == f'ΚΕΦΑΛΑΙΟ {chapter}']
        header = [s['text'] for s in spans(first) if s['bbox'][1] < 45]
        footer = [s['text'] for s in spans(first) if s['bbox'][1] > first.rect.height-45]
        full_opening = norm('\n'.join(s['text'] for s in large))
        full_body = norm('\n'.join(s['text'] for s in title))
        goal_count = sum(s['text'].count('•') for s in spans(opening))
        goals_present = goal_count == expected['learning_goals'] and 'Τι θα μάθουμε' in texts[opn-1]
        row = dict(expected)
        row.update({
            'opening_recto': opn % 2 == 1,
            'opening_label': f'ΕΝΟΤΗΤΑ {chapter}',
            'body_label': f'ΚΕΦΑΛΑΙΟ {chapter}',
            'opening_full_title': full_opening,
            'opening_title_tex_pt': round(large[0]['size']/BP_PER_PT, 5),
            'opening_title_line_count': len({round(s['bbox'][1], 2) for s in large}),
            'body_full_title': full_body,
            'body_title_tex_pt': round(title[0]['size']/BP_PER_PT, 5),
            'body_title_pdf_bp': round(title[0]['size'], 5),
            'body_title_font': title[0]['font'],
            'body_label_font': label[0]['font'] if label else None,
            'body_label_tex_pt': round(label[0]['size']/BP_PER_PT, 5) if label else None,
            'body_title_line_count': len({round(s['bbox'][1], 2) for s in title}),
            'body_title_emissions_on_page': len(label),
            'learning_goals_all_present': goals_present,
            'opening_header_footer_absent': not any(s['bbox'][1] < 45 or s['bbox'][1] > opening.rect.height-45 for s in spans(opening)),
            'running_header_text': header, 'footer_text': footer,
        })
        row['passed'] = all((row['opening_recto'], row['opening_label'] in texts[opn-1],
            full_opening == expected['opening_full_title'], full_body == expected['opening_full_title'],
            title[0]['font'] == 'NotoSerif-Medium', len(label) == 1,
            label[0]['font'] == 'Inter-Medium' if label else False,
            goals_present, row['opening_header_footer_absent'], str(body) in footer))
        cases.append(row)
    markers = [dict(x, present=norm(x['marker']) in texts[x['page']-1]) for x in EXPECT['content_markers']]
    title_pages = [i+1 for i, page in enumerate(doc) if title_spans(page)]
    next_page = {'page': 3, 'no_body_chapter_label': 'ΚΕΦΑΛΑΙΟ' not in texts[2],
                 'no_large_title': not title_spans(doc[2]),
                 'short_running_header_retained': 'Σύντομη κεφαλίδα Α' in texts[2]}
    blank = {'page': 4, 'text_empty': not texts[3],
             'drawing_count': len(doc[3].get_drawings()), 'image_count': len(doc[3].get_images())}
    info = doc[0].get_image_info(xrefs=True)[0]
    box = fitz.Rect(info['bbox'])
    existing = R / design / 'source/assets/photo-K-3tones.png'
    embedded = Image.open(__import__('io').BytesIO(doc.extract_image(info['xref'])['image'])).convert('L')
    original = Image.open(existing).convert('L')
    photo = {'page': 1, 'bbox_pdf_bp': list(box),
             'width_mm': round(box.width*MM_PER_BP, 5), 'height_mm': round(box.height*MM_PER_BP, 5),
             'at_least_25_mm': box.height*MM_PER_BP >= 25,
             'within_configurable_60_mm_maximum': box.height*MM_PER_BP <= 60,
             'source_width_px': original.width, 'source_height_px': original.height,
             'source_aspect_ratio': round(original.width/original.height, 7),
             'rendered_aspect_ratio': round(box.width/box.height, 7),
             'aspect_ratio_retained': abs(box.width/box.height-original.width/original.height) < .00001,
             'embedded_pixels_equal_existing_source': embedded.size == original.size and embedded.tobytes() == original.tobytes(),
             'existing_source_sha256': sha(existing),
             'credit_present': norm('Υπάρχουσα φωτογραφία — η πηγή διατηρείται.') in texts[0]}
    vector = {'page': 9, 'raster_image_count': len(doc[8].get_images()),
              'drawing_count': len(doc[8].get_drawings()),
              'vector_preserved': not doc[8].get_images() and len(doc[8].get_drawings()) > 0,
              'credit_present': norm('Η ίδια διανυσματική εικονογράφηση, χωρίς αντικατάσταση.') in texts[8]}
    native = {'page': 11, 'number_5_present': 'Κεφάλαιο 5' in texts[10],
              'native_title_once': texts[10].count('Κανονικό εγγενές κεφάλαιο') == 1,
              'custom_title_not_injected': 'ΚΕΦΑΛΑΙΟ' not in texts[10] and not title_spans(doc[10]),
              'native_heading_font': [s['font'] for s in spans(doc[10]) if s['size'] > 24][0],
              'font_sizes_tex_pt': sorted({round(s['size']/BP_PER_PT,5) for s in spans(doc[10])})}
    fonts = fonts_evidence(doc)
    log = log_evidence(path.with_suffix('.log'))
    passes = []
    for n in (1, 2):
        stdout = path.with_suffix(f'.pass{n}.stdout')
        passes.append({'run': n, 'stdout': rel(stdout), 'sha256': sha(stdout),
                       'warning_count': stdout.read_text(errors='replace').count('Warning:'),
                       'rerun_messages_resolved_on_final_pass': log['counts']['rerun_needed'] == 0})
    previews = [panel(doc, design, profile, name, pages) for name, pages in PAIRS.items()]
    row = {'design': design, 'profile': profile, 'pdf': rel(path), 'sha256': sha(path),
           'bytes': path.stat().st_size, 'page_count': len(doc), 'page_dimensions_mm': dims,
           'dimensions_match_170x240_within_0_003_mm': all(abs(w-170)<.003 and abs(h-240)<.003 for w,h in dims),
           'opening_cases': cases, 'content_markers': markers,
           'title_pages_at_17_5_tex_pt': title_pages,
           'exactly_one_custom_body_title_per_chapter': title_pages == [2,6,8,10] and all(x['body_title_emissions_on_page']==1 for x in cases),
           'next_page': next_page, 'recto_parity_blank_page': blank,
           'photo': photo, 'vector_artwork': vector, 'native_chapter': native,
           'fonts': fonts, 'all_fonts_embedded': all(f['embedded_bytes']>0 for f in fonts),
           'final_log': log, 'build_passes': passes, 'previews': [p['path'] for p in previews]}
    row['passed'] = all((len(doc)==11, row['dimensions_match_170x240_within_0_003_mm'],
        all(c['passed'] for c in cases), all(m['present'] for m in markers),
        row['exactly_one_custom_body_title_per_chapter'], all(v for k,v in next_page.items() if k!='page'),
        blank['text_empty'], blank['drawing_count']==0, blank['image_count']==0,
        photo['at_least_25_mm'], photo['within_configurable_60_mm_maximum'], photo['aspect_ratio_retained'],
        photo['embedded_pixels_equal_existing_source'], photo['credit_present'], vector['vector_preserved'],
        vector['credit_present'], native['number_5_present'], native['native_title_once'], native['custom_title_not_injected'],
        row['all_fonts_embedded'], all(v==0 for k,v in log['counts'].items() if k!='warnings'),
        log['only_expected_unused_caption_warnings']))
    return row, previews


def final_extra_edge(design, profile):
    """Compile the existing fixture without the archived local style shadow."""
    src = R / design / 'source'
    out = D / 'extra-edges' / f'{design}_{profile}'
    out.mkdir(parents=True, exist_ok=True)
    local = src / '.local'
    cache = out / 'runtime'
    for folder in ('tmp','cache','texmf-var','texmf-config'):
        (cache/folder).mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update({'TMPDIR': str(cache/'tmp'), 'TMP':str(cache/'tmp'), 'TEMP':str(cache/'tmp'),
        'PYTHONDONTWRITEBYTECODE':'1', 'FONTCONFIG_FILE':str(local/'fontconfig.xml'),
        'OSFONTDIR':str(local/'fonts'), 'TEXMFHOME':str(local/'texmf'),
        'TEXMFVAR':str(cache/'texmf-var'), 'TEXMFCONFIG':str(cache/'texmf-config'),
        'XDG_CACHE_HOME':str(cache/'cache'), 'TEXMFCACHE':str(cache/'cache'),
        'TEXFORMATS':str(R/'runtime/texmf-var/web2c/xetex')+':',
        'TEXINPUTS':str(src)+'//:'})
    fixture = D / 'extra-edges/deferred-edge-probe.tex'
    prefix = r'\def\ProbePrint{1}' if profile == 'PRINT' else ''
    command = ['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error','-recorder',
        '-output-directory='+str(out),'-jobname=probe',prefix+r'\input{'+str(fixture)+'}']
    returncodes = []
    for n in (1,2):
        with (out/f'run{n}.stdout').open('w') as stdout:
            result = subprocess.run(command,cwd=src,env=env,stdout=stdout,stderr=subprocess.STDOUT)
        returncodes.append(result.returncode)
        if result.returncode: break
    path = out/'probe.pdf'
    if returncodes != [0,0]:
        return {'design':design,'profile':profile,'returncodes':returncodes,'passed':False}
    doc = fitz.open(path)
    texts = [norm(p.get_text()) for p in doc]
    markers = ('FIRSTFLOATBODY','FIRSTLONGTABLEBODY','FIRSTDISPLAYBODY','FIRSTLISTBODY',
               'FIRSTMINIPAGEBODY','FIRSTWORKEDBODY','FIRSTATTENTIONBODY')
    checks = []
    for chapter,(page,marker) in enumerate(zip((2,4,6,8,10,12,14),markers),1):
        pg=doc[page-1]; title=title_spans(pg)
        marker_spans=[s for s in spans(pg) if marker in s['text']]
        bottom=max(s['bbox'][3] for s in title)
        first_y=min(s['bbox'][1] for s in marker_spans) if marker_spans else None
        item={'chapter':chapter,'page':page,'marker':marker,'marker_present':bool(marker_spans),
              'body_title_label_once':texts[page-1].count(f'ΚΕΦΑΛΑΙΟ {chapter}')==1,
              'body_title_bottom_pdf_bp':bottom,'marker_top_pdf_bp':first_y,
              'content_below_title':first_y is not None and first_y>bottom}
        if page==2:
            # The 40 x 10 mm rule is the actual first float graphic, not its caption.
            graphics=[draw['rect'] for draw in pg.get_drawings()
                      if abs(draw['rect'].width-40/MM_PER_BP)<1 and abs(draw['rect'].height-10/MM_PER_BP)<1]
            item['float_graphic_rects_pdf_bp']=[list(b) for b in graphics]
            item['float_graphic_below_title']=len(graphics)==1 and graphics[0].y0>bottom
        item['passed']=all(v for k,v in item.items() if k in ('marker_present','body_title_label_once','content_below_title','float_graphic_below_title'))
        checks.append(item)
    fls=(out/'probe.fls').read_text(errors='replace')
    style_paths={line[6:] for line in fls.splitlines() if line.startswith('INPUT ') and any(line.endswith(name) for name in
                 ('universalbook.sty','book-editorial-openings.tex','book-editorial-flow.tex'))}
    # Recorder entries can be source-relative because the build cwd is the source root.
    resolved=sorted({str((src/Path(p)).resolve()) if not Path(p).is_absolute() else str(Path(p).resolve()) for p in style_paths})
    final_inputs=all(p.startswith(str(src)+'/') for p in resolved) and all(any(p.endswith(name) for p in resolved) for name in
                     ('universalbook.sty','book-editorial-openings.tex','book-editorial-flow.tex'))
    log=log_evidence(out/'probe.log')
    title_pages=[i+1 for i,p in enumerate(doc) if title_spans(p)]
    row={'design':design,'profile':profile,'kind':'final-extra-edges','returncodes':returncodes,
         'fixture':rel(fixture),'fixture_sha256':sha(fixture),'pdf':rel(path),'sha256':sha(path),
         'pages':len(doc),'blank_pages':[i+1 for i,t in enumerate(texts) if not t],
         'body_title_pages':title_pages,'first_content_checks':checks,
         'measurement_box_did_not_consume_title':checks[0]['body_title_label_once'],
         'native_chapter_cancels_pending': 'FIRSTNATIVEBODY' in texts[-1] and 'ΚΕΦΑΛΑΙΟ' not in texts[-1] and not title_spans(doc[-1]),
         'native_page':len(doc),'final_candidate_inputs_only':final_inputs,
         'style_inputs':resolved,'recorder':rel(out/'probe.fls'),'recorder_sha256':sha(out/'probe.fls'),
         'source_fingerprints':[{'path':rel(src/name),'sha256':sha(src/name)} for name in
             ('styles/universalbook.sty','styles/book-editorial-openings.tex','styles/book-editorial-flow.tex')],
         'xelatex_format':{'path':rel(R/'runtime/texmf-var/web2c/xetex/xelatex.fmt'),
                           'sha256':sha(R/'runtime/texmf-var/web2c/xetex/xelatex.fmt')},
         'final_log':log}
    # The extra fixture has a figure caption, but no table caption.
    row['passed']=all((len(doc)==17,title_pages==[2,4,6,8,10,12,14],
        row['blank_pages']==[16],all(c['passed'] for c in checks),row['native_chapter_cancels_pending'],
        final_inputs,all(v==0 for k,v in log['counts'].items() if k!='warnings'),
        len(log['warning_lines'])==1 and log['warning_lines'][0].startswith(r'Package caption Warning: Unused \captionsetup[table]')))
    (out/'FINAL_RESULT.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    return row


def augment_extra_evidence(result):
    previews=[]
    for row in result['results']:
        doc=fitz.open(R/row['pdf'])
        for check in row['first_content_checks']:
            pg=doc[check['page']-1]
            content=[s for s in spans(pg) if 45<s['bbox'][1]<pg.rect.height-45
                     and abs(s['size']-TITLE_BP)>=.001 and not s['text'].startswith('ΚΕΦΑΛΑΙΟ ')]
            check['first_structure_top_pdf_bp']=min(s['bbox'][1] for s in content)
            check['first_structure_below_title']=check['first_structure_top_pdf_bp']>check['body_title_bottom_pdf_bp']
            check['passed']=check['passed'] and check['first_structure_below_title']
        row['passed']=row['passed'] and all(c['passed'] for c in row['first_content_checks'])
        if row['design']=='MINIMAL' and row['profile']=='SCREEN':
            for page in (2,4,6,8,10,12,14,17):
                out=(R/row['pdf']).parent/f'page-{page:02}.png'
                pix=doc[page-1].get_pixmap(dpi=120,alpha=False);pix.save(out)
                previews.append({'page':page,'path':rel(out),'source_pdf_sha256':row['sha256'],
                    'sha256':sha(out),'pixel_dimensions':[pix.width,pix.height],'dpi':120})
            ((R/row['pdf']).parent/'FINAL_PREVIEWS.json').write_text(json.dumps(previews,ensure_ascii=False,indent=2)+'\n')
        ((R/row['pdf']).parent/'FINAL_RESULT.json').write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    result['preview_pngs']=previews
    result['all_passed']=all(row['passed'] for row in result['results'])
    (D/'extra-edges/EXTRA_EDGE_RESULTS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    return result


def write_markdown(result):
    lines=['# Final opening and authoring API proof — v1.0.11','',
        '**Result: passed with expected caption warnings.** The four opening PDFs and four first-content PDFs were rebuilt against the final frozen candidate sources. Candidate source files were not edited by this proof task.','',
        '## PDF evidence','',
        '| Design | Profile | Pages | Long photo body title | SHA-256 |',
        '|---|---|---:|---|---|']
    for row in result['pdfs']:
        lines.append(f"| {row['design']} | {row['profile']} | {row['page_count']} | 3 lines, 17.5 TeX pt | `{row['sha256']}` |")
    lines += ['',
        'All pages measure 170 × 240 mm within 0.003 mm. The body title uses embedded Noto Serif Medium at 17.5 TeX pt (17.43462 PDF bp); the smaller chapter label uses Inter Medium at 9.5 TeX pt. All seven PDF fonts are embedded.','',
        'The final opening helper SHA-256 is `'+EXPECTED_HELPER+'`. The JSON records final universalbook, opening, flow, configuration, log and preview hashes. Extra-case TeX recorder files confirm that all three style inputs came from the final candidate source directories, including the final flow helper.','',
        '## Entry patterns and pagination','',
        '| Chapter | Separate opening | First body page | First content | Goals |',
        '|---|---:|---:|---|---:|']
    for c in result['pdfs'][0]['opening_cases']:
        lines.append(f"| {c['chapter']} | {c['opening_page']} | {c['body_page']} | {c['entry_pattern']} | {c['learning_goals']} |")
    lines += ['',
        '- All separate openings remain odd, right-hand pages 1/5/7/9, with no running header or page-number footer. Page 4 is fully blank and preserves recto parity.',
        '- Each custom chapter receives one body title on pages 2/6/8/10. The next page 3 retains the supplied short running header and footer without another large title. Normal running headers remain on body pages.',
        '- Full photo and no-photo titles, subtitles, learning-goal items, photo/vector credits, first content, diagram labels and callout mathematics are present. Both long body titles wrap cleanly in three lines.',
        '- Existing photograph pixels and source asset hashes match the protected v1.0.10 SHA-256 snapshot in `reports/SOURCE_BASELINE.json`. The proof needs no staging directory or original repository. Its aspect ratio is preserved; stress photo height is 57.95111 mm in REFINED and 49.95063 mm in MINIMAL, within the configured 25–60 mm range. The opening artwork remains vector paths.',
        '- Native chapter 5 on page 11 retains one native title with no custom body title injection.','',
        '## Deferred first-content proof','',
        'Four additional PDFs test a measured header/parbox followed by a float, plus first longtable, display equation, list, minipage, workedexample and AttentionBox. All seven body titles appear once on pages 2/4/6/8/10/12/14, before the first content structure. The float graphic itself also remains below the title. Header measurement does not consume the pending title. A native chapter cancels the final pending custom title and appears alone on page 17; page 16 is blank.','',
        '| Design | Profile | Pages | SHA-256 |',
        '|---|---|---:|---|']
    for row in result['deferred_first_content']['results']:
        lines.append(f"| {row['design']} | {row['profile']} | {row['pages']} | `{row['sha256']}` |")
    lines += ['',
        'The packaged extra-case evidence is [EXTRA_EDGE_RESULTS.json](extra-edges/EXTRA_EDGE_RESULTS.json), with recorder input paths and measurements. Its fixture, final PDFs, logs, recorder files and previews are together in `extra-edges`. The PDF bytes and recorder contents are unchanged from compilation; the JSON records their original compile paths and the clean packaged paths. The separate full compatibility QA covers the strict 18-page worksheet/assessment fixture.','',
        '## Warnings and visual review','',
        'There are no overfull/underfull boxes, missing characters, unresolved references, final-pass rerun requests or TeX errors in these eight final logs. Each opening-only probe has exactly two expected warnings for unused figure/table caption setups. Each extra-case probe has a figure caption and only the expected unused table caption setup warning. No warnings were suppressed.','',
        'All 20 final 120 dpi comparison panels were visually inspected, covering every nonblank opening-fixture page in both designs and profiles. No clipped title, overlap, displaced goal, missing credit, header/footer leak on an opening, or repeated large title was observed. The final rebuild after the heading-space adjustment is pixel-identical to the reviewed panels. Eight extra-case MINIMAL/SCREEN pages were also visually inspected, including first-float ordering and native cancellation. The JSON binds each preview to its actual final PDF hash.','',
        '| Design / profile | Long opening + body | No photo + section | Callout | Paragraph + native | Next + paragraph opening |',
        '|---|---|---|---|---|---|']
    for row in result['pdfs']:
        prefix=f"{row['design']}_{row['profile']}"
        links=[f'[{name}]({prefix}_{name}.png)' for name in PAIRS]
        lines.append('| '+row['design']+' / '+row['profile']+' | '+' | '.join(links)+' |')
    lines += ['',
        'Panels pair full pages at the same 120 dpi without resizing, under a separate label strip; they are comparisons rather than physical facing spreads. The proof checks authoring behavior and page layout; it does not select a design or grant press approval.','']
    (D/'OPENING_PROBE_REPORT.md').write_text('\n'.join(lines))


def main():
    for design in DESIGNS:
        assert sha(R/design/'source/styles/book-editorial-openings.tex') == EXPECTED_HELPER
    if '--extra-only' in sys.argv:
        with ThreadPoolExecutor(max_workers=2) as pool:
            edges=list(pool.map(lambda pair:final_extra_edge(*pair),[(d,p) for d in DESIGNS for p in PROFILES]))
        result=augment_extra_evidence({'generated_utc':datetime.now(timezone.utc).isoformat(),'all_passed':all(x['passed'] for x in edges),'results':edges})
        print(json.dumps({'all_passed':result['all_passed'],'results':[{k:x[k] for k in ('design','profile','passed')} for x in edges]},indent=2))
        return 0 if result['all_passed'] else 1
    rows,previews=[],[]
    for design in DESIGNS:
        for profile in PROFILES:
            row,pngs=opening_evidence(design,profile); rows.append(row);previews.extend(pngs)
    source_names=('styles/universalbook.sty','styles/book-editorial-openings.tex','styles/book-editorial-flow.tex',
                  'styles/book-assets.tex','config/book-config.tex','config/editorial-config.tex',
                  'config/editorial-design.tex','config/generated-assets.tex')
    fingerprints=[{'path':rel(R/d/'source'/name),'sha256':sha(R/d/'source'/name)} for d in DESIGNS for name in source_names]
    baseline_path=R/'reports/SOURCE_BASELINE.json'
    baseline=json.loads(baseline_path.read_text())
    assert baseline['stable_version']=='1.0.10'
    assets=[]
    for design in DESIGNS:
        for name in ('assets/photo-K-3tones.png','assets/math-chapter-art.tex'):
            a=R/design/'source'/name
            recorded_path=baseline['repository'].rstrip('/')+'/'+name
            protected_sha256=baseline['protected_files'][recorded_path]
            assets.append({'design':design,'path':name,'sha256':sha(a),
                'baseline_manifest':rel(baseline_path),'baseline_recorded_path':recorded_path,
                'protected_baseline_sha256':protected_sha256,'unchanged':sha(a)==protected_sha256})
    edges=augment_extra_evidence(json.loads((D/'extra-edges/EXTRA_EDGE_RESULTS.json').read_text()))
    result={'schema_version':2,'generated_utc':datetime.now(timezone.utc).isoformat(),
        'status':'passed_with_expected_warnings' if all(r['passed'] for r in rows) and edges['all_passed'] else 'failed',
        'scope':'Independent final opening/API probe. Four rebuilt PDFs use final candidate sources; extra first-content cases are compiled with the final candidate styles and verified by TeX recorder. These are review candidates, not stable adoption or press approval.',
        'request':'REQUEST.md','method':{'pdf_parser':'PyMuPDF '+fitz.VersionBind,
            'font_unit_note':'PDF font sizes use bp (1/72 in); requested TeX pt uses 1/72.27 in. Thus 17.5 TeX pt = 17.43462 PDF bp.',
            'render_dpi':120,'page_size_mm':[170,240],
            'png_layout':'Each 170 × 240 mm page is rendered at the same 120 dpi without resizing, paired side by side under a separate 38 px label strip and a 24 px gutter. Pairs are comparison panels, not physical facing spreads.',
            'visual_review':'All 20 comparison panels viewed; all nonblank opening-fixture pages covered. Eight MINIMAL SCREEN extra-case pages viewed. Final rebuild panels are pixel-identical to reviewed images.'},
        'expected_warning_explanation':'Each opening-only final log has two caption warnings for unused figure/table caption setups. The extra-edge fixture has a figure caption and therefore only the unused table setup warning. No final-pass rerun request or bad box is accepted.',
        'pdfs':rows,'source_fingerprints':fingerprints,
        'asset_baseline':{'path':rel(baseline_path),'sha256':sha(baseline_path),
                          'stable_version':baseline['stable_version'],'recorded_at_utc':baseline['recorded_at_utc']},
        'asset_preservation':assets,'preview_pngs':previews,
        'deferred_first_content':edges,
        'all_checks_passed':all(x['passed'] for x in rows) and all(a['unchanged'] for a in assets) and edges['all_passed']}
    reviewed=json.loads((D/'VISUALLY_REVIEWED_PANEL_HASHES.json').read_text())
    result['visual_review']={'reviewed_comparison_panels':20,'reviewed_extra_pages':8,
        'all_final_renders_pixel_identical_to_reviewed':all(sha(R/p['path'])==reviewed[str((R/p['path']).relative_to(D))] for p in previews+edges['preview_pngs']),
        'findings':'No clipped title, overlap, displaced learning goal, missing credit, opening header/footer leak, repeated large title, or native-title injection observed.'}
    result['all_checks_passed']=result['all_checks_passed'] and result['visual_review']['all_final_renders_pixel_identical_to_reviewed']
    result['status']='passed_with_expected_warnings' if result['all_checks_passed'] else 'failed'
    (D/'OPENING_PROBE_REPORT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    write_markdown(result)
    print(json.dumps({'status':result['status'],'pdfs':[{k:r[k] for k in ('design','profile','sha256','passed')} for r in rows],
                      'previews':len(previews),'extra_edge_cases_passed':edges['all_passed']},indent=2))
    return 0 if result['all_checks_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
