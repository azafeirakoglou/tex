# Final opening and authoring API proof — v1.0.11

**Result: passed with expected caption warnings.** The four opening PDFs and four first-content PDFs were rebuilt against the final frozen candidate sources. Candidate source files were not edited by this proof task.

## PDF evidence

| Design | Profile | Pages | Long photo body title | SHA-256 |
|---|---|---:|---|---|
| REFINED | SCREEN | 11 | 3 lines, 17.5 TeX pt | `e75ff8c11ab986346ce4da4424b1d318ffdc4bf64c39388f9e1f7db0d1698777` |
| REFINED | PRINT | 11 | 3 lines, 17.5 TeX pt | `0aa8d296efbf93356870239c33148ea1ef671b680a5b33fd31cbebb369e72e93` |
| MINIMAL | SCREEN | 11 | 3 lines, 17.5 TeX pt | `a1bb2fc3e6e4041d11496d8d2e4a8f6b49ec7284eaef7073b707da3edb3165a2` |
| MINIMAL | PRINT | 11 | 3 lines, 17.5 TeX pt | `1b919bb04c57ad42713a29fc90ac567a1ae03190ba34dd00ecf3de3ece22f57b` |

All pages measure 170 × 240 mm within 0.003 mm. The body title uses embedded Noto Serif Medium at 17.5 TeX pt (17.43462 PDF bp); the smaller chapter label uses Inter Medium at 9.5 TeX pt. All seven PDF fonts are embedded.

The final opening helper SHA-256 is `d42a60c89940c57836664319ee573a85d87b534c9fe5f5aa839030fec5e3b0b4`. The JSON records final universalbook, opening, flow, configuration, log and preview hashes. Extra-case TeX recorder files confirm that all three style inputs came from the final candidate source directories, including the final flow helper.

## Entry patterns and pagination

| Chapter | Separate opening | First body page | First content | Goals |
|---|---:|---:|---|---:|
| 1 | 1 | 2 | BookChapterPhoto + BookSection + section | 5 |
| 2 | 5 | 6 | BookChapter without photograph + direct section | 4 |
| 3 | 7 | 8 | BookChapter + paragraph | 3 |
| 4 | 9 | 10 | BookChapterPhoto + ThinkBox | 3 |

- All separate openings remain odd, right-hand pages 1/5/7/9, with no running header or page-number footer. Page 4 is fully blank and preserves recto parity.
- Each custom chapter receives one body title on pages 2/6/8/10. The next page 3 retains the supplied short running header and footer without another large title. Normal running headers remain on body pages.
- Full photo and no-photo titles, subtitles, learning-goal items, photo/vector credits, first content, diagram labels and callout mathematics are present. Both long body titles wrap cleanly in three lines.
- Existing photograph pixels and source asset hashes match the protected v1.0.10 SHA-256 snapshot in `reports/SOURCE_BASELINE.json`. The proof needs no staging directory or original repository. Its aspect ratio is preserved; stress photo height is 57.95111 mm in REFINED and 49.95063 mm in MINIMAL, within the configured 25–60 mm range. The opening artwork remains vector paths.
- Native chapter 5 on page 11 retains one native title with no custom body title injection.

## Deferred first-content proof

Four additional PDFs test a measured header/parbox followed by a float, plus first longtable, display equation, list, minipage, workedexample and AttentionBox. All seven body titles appear once on pages 2/4/6/8/10/12/14, before the first content structure. The float graphic itself also remains below the title. Header measurement does not consume the pending title. A native chapter cancels the final pending custom title and appears alone on page 17; page 16 is blank.

| Design | Profile | Pages | SHA-256 |
|---|---|---:|---|
| REFINED | SCREEN | 17 | `0ef3b60ff6cbc320fcdabaf519c504da8a140ea624ad561682a5580314b79b54` |
| REFINED | PRINT | 17 | `2a27b5b46aa271ad5bf0c5bd49c9e038040b99defcdeb10e627ea603288c87cc` |
| MINIMAL | SCREEN | 17 | `d21308161056540f9e3580237eaee08d40142f74ac7e48255819cc3269d2a19f` |
| MINIMAL | PRINT | 17 | `83c61b860e5d23830d40e56d3944b3df9b3bf6720c07e8ac5f53f7d3a2b03078` |

The packaged extra-case evidence is [EXTRA_EDGE_RESULTS.json](extra-edges/EXTRA_EDGE_RESULTS.json), with recorder input paths and measurements. Its fixture, final PDFs, logs, recorder files and previews are together in `extra-edges`. The PDF bytes and recorder contents are unchanged from compilation; the JSON records their original compile paths and the clean packaged paths. The separate full compatibility QA covers the strict 18-page worksheet/assessment fixture.

## Warnings and visual review

There are no overfull/underfull boxes, missing characters, unresolved references, final-pass rerun requests or TeX errors in these eight final logs. Each opening-only probe has exactly two expected warnings for unused figure/table caption setups. Each extra-case probe has a figure caption and only the expected unused table caption setup warning. No warnings were suppressed.

All 20 final 120 dpi comparison panels were visually inspected, covering every nonblank opening-fixture page in both designs and profiles. No clipped title, overlap, displaced goal, missing credit, header/footer leak on an opening, or repeated large title was observed. The final rebuild after the heading-space adjustment is pixel-identical to the reviewed panels. Eight extra-case MINIMAL/SCREEN pages were also visually inspected, including first-float ordering and native cancellation. The JSON binds each preview to its actual final PDF hash.

| Design / profile | Long opening + body | No photo + section | Callout | Paragraph + native | Next + paragraph opening |
|---|---|---|---|---|---|
| REFINED / SCREEN | [long-opening-body](REFINED_SCREEN_long-opening-body.png) | [no-photo](REFINED_SCREEN_no-photo.png) | [callout](REFINED_SCREEN_callout.png) | [paragraph-native](REFINED_SCREEN_paragraph-native.png) | [next-and-paragraph-opening](REFINED_SCREEN_next-and-paragraph-opening.png) |
| REFINED / PRINT | [long-opening-body](REFINED_PRINT_long-opening-body.png) | [no-photo](REFINED_PRINT_no-photo.png) | [callout](REFINED_PRINT_callout.png) | [paragraph-native](REFINED_PRINT_paragraph-native.png) | [next-and-paragraph-opening](REFINED_PRINT_next-and-paragraph-opening.png) |
| MINIMAL / SCREEN | [long-opening-body](MINIMAL_SCREEN_long-opening-body.png) | [no-photo](MINIMAL_SCREEN_no-photo.png) | [callout](MINIMAL_SCREEN_callout.png) | [paragraph-native](MINIMAL_SCREEN_paragraph-native.png) | [next-and-paragraph-opening](MINIMAL_SCREEN_next-and-paragraph-opening.png) |
| MINIMAL / PRINT | [long-opening-body](MINIMAL_PRINT_long-opening-body.png) | [no-photo](MINIMAL_PRINT_no-photo.png) | [callout](MINIMAL_PRINT_callout.png) | [paragraph-native](MINIMAL_PRINT_paragraph-native.png) | [next-and-paragraph-opening](MINIMAL_PRINT_next-and-paragraph-opening.png) |

Panels pair full pages at the same 120 dpi without resizing, under a separate label strip; they are comparisons rather than physical facing spreads. The proof checks authoring behavior and page layout; it does not select a design or grant press approval.
