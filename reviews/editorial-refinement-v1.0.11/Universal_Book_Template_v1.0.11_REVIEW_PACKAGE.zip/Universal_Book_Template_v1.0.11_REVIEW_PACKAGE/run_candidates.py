#!/usr/bin/env python3
"""Build two independent review candidates. No Git or release operation."""
from pathlib import Path
import os,sys,json,shutil,subprocess,argparse,hashlib
from concurrent.futures import ThreadPoolExecutor
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parent
os.environ['TMPDIR']=str(ROOT/'runtime/tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
DESIGNS=['REFINED','MINIMAL']

def source(design):return ROOT/design/'source'
def environment(src):
    env=os.environ.copy();local=src/'.local'
    env.update({'TMPDIR':str(ROOT/'runtime/tmp'),'TMP':str(ROOT/'runtime/tmp'),'TEMP':str(ROOT/'runtime/tmp'),
      'PYTHONDONTWRITEBYTECODE':'1','FONTCONFIG_FILE':str(local/'fontconfig.xml'),'OSFONTDIR':str(local/'fonts'),
      'TEXMFHOME':str(local/'texmf'),'TEXMFVAR':str(local/'texmf-var'),'TEXMFCONFIG':str(local/'texmf-config'),
      'XDG_CACHE_HOME':str(local/'cache'),'TEXMFCACHE':str(local/'cache/texmf')})
    return env

def prepare():
    for folder in ['pdf','logs','qa','previews','runtime/tmp','runtime/texmf-var','runtime/texmf-config','runtime/cache']:(ROOT/folder).mkdir(parents=True,exist_ok=True)
    for design in DESIGNS:
        src=source(design)
        if not src.exists():shutil.copytree(ROOT/'working-base',src)
        (src/'config/editorial-design.tex').write_text('% Independent review candidate; no stable adoption.\n\\BookEditorialMinimal'+('true' if design=='MINIMAL' else 'false')+'\n')
        local=src/'.local';local.mkdir(exist_ok=True)
        for folder in ['fonts','texmf','texmf-var']:
            target=local/folder
            if not target.exists() and not target.is_symlink():target.symlink_to(ROOT/'runtime'/folder,target_is_directory=True)
        for folder in ['cache/fontconfig','texmf-config']:(local/folder).mkdir(parents=True,exist_ok=True)
        xml='<?xml version="1.0"?>\n<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">\n<fontconfig>'
        xml+=''.join('<dir>'+escape(str(d))+'</dir>' for d in [local/'fonts',Path('/usr/share/fonts/truetype/dejavu')] if d.exists())
        xml+='<cachedir>'+escape(str(local/'cache/fontconfig'))+'</cachedir></fontconfig>\n'
        (local/'fontconfig.xml').write_text(xml)
        subprocess.run(['fc-cache','--force'],env=environment(src),stdout=subprocess.DEVNULL,check=True)
        subprocess.run([sys.executable,'scripts/check_color_consistency.py'],cwd=src,env=environment(src),check=True,stdout=subprocess.DEVNULL)
    (ROOT/'CANDIDATE_MANIFEST.json').write_text(json.dumps({'version':'1.0.11','status':'independent_review_candidates_not_stable','base_stable':'1.0.10','designs':DESIGNS,'page_mm':[170,240],'margins_mm':{'inner':20,'outer':17,'top':19,'bottom':20},'math_scale':1.05,'approval_required_for':'merge, push, release, stable adoption'},ensure_ascii=False,indent=2)+'\n')

def build(design,target):
    src=source(design);out=ROOT/'logs'/(design+'_'+target+'.log')
    with out.open('w') as f:r=subprocess.run([sys.executable,'scripts/build.py',target],cwd=src,env=environment(src),stdout=f,stderr=subprocess.STDOUT)
    if r.returncode:
        print('FAILED',design,target,out,flush=True);return {'design':design,'target':target,'status':'failed','log':str(out)}
    if target in ['screen','print2']:
        folder,job,profile=('screen','Physics_A_Screen','SCREEN') if target=='screen' else ('print','Physics_A_Print_Technical','PRINT')
        p=src/'build'/folder/(job+'.pdf');dest=ROOT/'pdf'/f'v1.0.11_{design}_{profile}.pdf';shutil.copy2(p,dest)
        row={'design':design,'target':target,'status':'passed','pdf':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'log':str(out)}
    else:row={'design':design,'target':target,'status':'passed','log':str(out)}
    print('BUILT',design,target,flush=True);return row

def main():
    p=argparse.ArgumentParser();p.add_argument('--prepare-only',action='store_true');p.add_argument('--designs',nargs='*',default=DESIGNS);p.add_argument('--targets',nargs='*',default=['screen','print2']);p.add_argument('--jobs',type=int,default=2);a=p.parse_args()
    prepare()
    if a.prepare_only:return 0
    work=[(d,t) for d in a.designs for t in a.targets]
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:rows=list(pool.map(lambda x:build(*x),work))
    (ROOT/'BUILD_RESULTS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    return 0 if all(r['status']=='passed' for r in rows) else 1
if __name__=='__main__':raise SystemExit(main())
