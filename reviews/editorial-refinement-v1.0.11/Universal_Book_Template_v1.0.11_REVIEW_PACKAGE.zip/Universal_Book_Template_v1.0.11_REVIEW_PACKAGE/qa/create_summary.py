#!/usr/bin/env python3
"""Consolidate machine-readable candidate QA into a compact review report."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
QA = ROOT / 'qa'


def read(relative, fallback=None):
    path = ROOT / relative
    return json.loads(path.read_text()) if path.exists() else fallback


def current_pair_report(row):
    report = read(row['report'], {})
    if report.get('status') != 'passed':
        return False
    for key, field in (('print', 'print_file'), ('screen', 'screen_file')):
        path = Path(report.get(field, ''))
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != report.get('input_sha256', {}).get(key):
            return False
    return True


def main():
    color = read('qa/COLOR_INVARIANCE.json', {})
    main_flow = read('qa/MAIN_FLOW.json', {})
    units = read('qa/suites/RESULTS.json', [])
    compat = read('qa/compat/BUILD_RESULTS.json', [])
    pairs = read('qa/compat/PREFLIGHT_RESULTS.json', [])
    probes = read('qa/probes/BUILD_RESULTS.json', [])
    probe_pairs = read('qa/probes/PREFLIGHT_RESULTS.json', [])
    stress = {d: read('qa/compat/' + d + '/stress.structure.json', {})
              for d in ('REFINED', 'MINIMAL')}
    audits = {d: read('qa/compat/' + d + '/build_log_audit.json', [])
              for d in ('REFINED', 'MINIMAL')}
    counts = {}
    for row in units:
        content = (ROOT / row['log']).read_text()
        match = re.search(r'Ran (\d+) tests', content)
        counts[row['design']] = int(match.group(1)) if match else 0
    checks = {
        'approved_palette_identical': color.get('status') == 'passed',
        'both_full_unit_suites_passed': len(units) == 2 and all(r['exit_code'] == 0 and r.get('skipped') == 0 for r in units),
        'both_unit_suites_retain_66_tests': counts == {'REFINED': 66, 'MINIMAL': 66},
        '40_author_compatibility_builds_passed': len(compat) == 40 and all(r['exit_code'] == 0 for r in compat),
        '20_author_compatibility_pair_preflights_passed': len(pairs) == 20 and all(r['exit_code'] == 0 for r in pairs),
        'both_original_stress_structural_checks_passed': all(r.get('status') == 'passed' for r in stress.values()),
        'all_8_editorial_fixture_measurements_passed': len(probes) == 8 and all(r['status'] == 'passed' for r in probes),
        'all_8_editorial_fixture_logs_clean': len(probes) == 8 and all(r.get('diagnostics') and
            not any(r['diagnostics'].values()) for r in probes),
        'all_4_editorial_fixture_pair_preflights_passed': len(probe_pairs) == 4 and all(r['status'] == 'passed' for r in probe_pairs),
        'all_24_secondary_pair_reports_match_current_pdf_hashes': len(pairs + probe_pairs) == 24
            and all(current_pair_report(r) for r in pairs + probe_pairs),
        'all_8_editorial_measurements_match_current_pdf_hashes': len(probes) == 8 and all(
            read(r['report'], {}).get('input_sha256') == hashlib.sha256(Path(r['pdf']).read_bytes()).hexdigest()
            for r in probes),
        'all_4_main_thematic_headings_share_their_following_theorem_page':
            main_flow.get('status') == 'passed' and len(main_flow.get('pdfs', [])) == 4,
        'all_4_main_flow_reports_match_current_20_page_pdf_hashes':
            len(main_flow.get('pdfs', [])) == 4 and all(r.get('pages') == 20
                and r.get('input_sha256') == hashlib.sha256((ROOT / r['pdf']).read_bytes()).hexdigest()
                for r in main_flow.get('pdfs', [])),
    }
    main_logs = [dict(design=d, **r) for d, rows in audits.items() for r in rows
                 if r['target'] in ('screen', 'print2')]
    checks['main_4_pdf_logs_have_no_overfull_underfull_missing_or_warning'] = (
        len(main_logs) == 4 and all(not any(r[x] for x in ('overfull', 'underfull', 'missing_characters', 'warnings'))
                                   for r in main_logs))
    all_logs = [dict(design=d, **r) for d, rows in audits.items() for r in rows]
    checks['all_44_build_logs_have_no_overfull_or_missing_characters'] = (
        len(all_logs) == 44 and all(not r['overfull'] and not r['missing_characters'] for r in all_logs))
    source_hashes = {}
    for design in ('REFINED', 'MINIMAL'):
        source_hashes[design] = {str(p.relative_to(ROOT / design / 'source')): hashlib.sha256(p.read_bytes()).hexdigest()
                                for folder in ('config', 'styles')
                                for p in sorted((ROOT / design / 'source' / folder).glob('*')) if p.is_file()}
    report = {'status': 'passed' if all(checks.values()) else 'pending_or_failed',
              'created_utc': datetime.now(timezone.utc).isoformat(), 'checks': checks,
              'unit_test_counts': counts, 'main_pdf_diagnostics': main_logs,
              'main_flow_regression': main_flow,
              'build_diagnostic_totals': {d: {
                  'targets': len(rows), 'overfull': sum(r['overfull'] for r in rows),
                  'underfull': sum(r['underfull'] for r in rows),
                  'missing_characters': sum(r['missing_characters'] for r in rows)}
                  for d, rows in audits.items()},
              'editorial_probe_builds': probes, 'source_sha256_at_summary': source_hashes,
              'evidence': ['qa/COLOR_INVARIANCE.json', 'qa/MAIN_FLOW.json', 'qa/suites/RESULTS.json',
                           'qa/compat/BUILD_RESULTS.json', 'qa/compat/PREFLIGHT_RESULTS.json',
                           'qa/probes/BUILD_RESULTS.json', 'qa/probes/PREFLIGHT_RESULTS.json'],
              'scope': 'Both candidate sources, copied tests and validators, shipped author fixtures, actual-PDF editorial measurements. Main-pair and visual-review evidence are maintained separately by the review-package driver.'}
    (QA / 'QA_SUMMARY.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    rows = ['# v1.0.11 candidate technical QA', '', '**Status: ' + report['status'].upper() + '.** Review candidates; no stable adoption.', '',
            'The checks use XeLaTeX and the independently copied candidate sources. All output and runtime state stay inside the experiment. No original repository modules are imported.', '',
            '| Check | Result |', '|---|---|']
    rows.extend('| ' + k.replace('_', ' ') + ' | ' + ('PASS' if v else 'PENDING / FAIL') + ' |' for k, v in checks.items())
    rows += ['', '## Actual PDF typography', '',
             'All sizes below are TeX points, measured from the PDF after converting PDF big points by 72.27/72. Tolerance is 0.012 pt; text and math have separate assertions.', '',
             '| Role | Font | Size |', '|---|---|---:|',
             '| Body | Inter Regular | 10.95 |', '| Section / subsection | Noto Serif Medium | 13 / 11 |',
             '| Thematic heading | Noto Serif Medium | 11.7 |', '| First body-page chapter title | Noto Serif Medium | 17.5 |',
             '| First body-page chapter label | Inter Medium | 9.5 |',
             '| Worked example title | Noto Serif Medium | 10.7 |', '| Solution label | Inter Medium | 10.2 |',
             '| Attention / Think titles | Inter Medium | 9.5 |', '| Callout body | Inter Regular | 10 |',
             '| History title, preserved | Inter Medium | 9.2 |', '| Figure / table caption text | Inter Regular, upright | 9.5 |',
             '| Diagram label / tick text | Inter Regular | 9.5 / 8.5 |',
             '| Diagram label / tick math | STIX Two Math | 9.975 / 8.925 |',
             '| Table header / table body, preserved | Inter SemiBold / Inter Regular | 10 / 10 |',
             '| Running header / footer, preserved | Inter Regular | 8 |',
             '| Body inline and display base math | STIX Two Math | 11.4975 |',
             '| Callout base math / scripts | STIX Two Math | 10.5 / 7.35 |', '',
             'The display formula uses the same base math size as inline body math. Short and long ThinkBox cases verify 105% math, Greek and Latin variables, indices, fractions, roots, sums, limits and integrals. Upright units and a chemical formula are included for visual inspection.', '',
             '## Pagination and public authoring compatibility', '',
             'The editorial fixture checks photo and non-photo openings, long titles, and chapter starts with a paragraph, section or callout. Each first body page contains one chapter label and a 17.5 pt title; the next body page has neither repeated heading. The full page-style suite additionally checks worksheet and assessment starts and recto/verso headers.', '',
             'The controlled metrics PDF is three pages; each editorial edge PDF is 43 pages. Each long callout contains exactly 36 marked paragraphs. Begin/end markers and all rows must occur once and in order across at least three fragments. Vector icons must occur only in the first fragment. The 120-row table must retain every row, repeated headers, numbering and references across at least three pages. Figure, table and long-table captions must wrap with hanging alignment, Inter Regular 9.5 pt and the unchanged BookSecondary role; following text must return to black. The physics diagram retains vector horizontal and vertical axes and its sloping data line; its page contains no raster image.', '',
             'The shipped stress fixture independently checks 28-paragraph callouts, a 150-row multipage table, repeated heads, references and all chapter routes. Existing author commands and fixtures remain present. Tests retain all 66 methods per candidate; extractor assertions use actual word geometry where PDF spans merge leaders and page numbers.', '',
             'A separate main-book PDF regression locates the 11.7 pt «Απόδειξη — υπόδειγμα» thematic heading and the following «Πρόσθεση ίσων ποσοτήτων» theorem title. It asserts that both occupy the same page in every candidate/edition, with the theorem below the heading and without overlap. All four final PDFs keep the pair on physical page 19. Its SHA-256 hashes are checked again when generating this summary.', '',
             '## Exact colour and plate checks', '',
             'The approved v1.0.10 colour-role and PRINT/SCREEN palette TeX files match their captured SHA-256 hashes byte for byte in both candidates. The JSON map differs only in version and AttentionBox geometric metadata. Every semantic role, ink definition, tint, spot name, alternate CMYK and SCREEN base value is identical. The frozen evidence is authenticated against reports/SOURCE_BASELINE.json.', '',
             'Each paired-PDF preflight checks all pages at 72 dpi with antialiasing disabled: all five process/spot separation plates, approved raster levels, absence of unintended RGB PRINT images, embedded fonts, page geometry, text and text positions, and paired SCREEN role colours. The editorial measurements independently verify every page at 170 × 240 mm. The unchanged review profile uses its MediaBox and does not introduce explicit press TrimBox metadata. All 24 secondary pair reports and eight measurement reports are checked against the current PDF SHA-256 hashes. These are engineering checks; the original printing approval/PDF-X status is unchanged.', '',
             '## Diagnostics and retained evidence', '',
             'Final main-PDF diagnostics are listed in QA_SUMMARY.json. All four main PDFs have 20 pages and no overfull/underfull boxes, missing characters or warnings. All eight editorial fixture logs are also clean. Secondary legacy figures and tables fixtures contain one empty underfull hbox each per edition (four per design); their content is byte-identical to the captured v1.0.10 fixture. Unused-caption and non-floating hypcap notices in fixtures are preserved in per-target audit logs. No test, public feature or warning was deleted to manufacture a pass.', '',
             'See `qa/probes/results/*_xelatex.log` for complete editorial-fixture logs, `qa/probes/pdf/` for compact QA PDFs, `qa/compat/*/build_log_audit.json` for all target diagnostics, and `qa/suites/*.unittest.log` for final full test results. Earlier failure/inspection artifacts are working evidence and are excluded from the review package. The copied tests retain all methods and strict page-count assertions. Geometry extraction distinguishes a thin running-header rule from the REFINED opening strip, and TOC assertions use actual word positions when PDF spans merge leaders with page numbers.', '',
             'Rendered visual evidence and editorial judgments are recorded separately under `visual-audit/` and the final editorial report. Successful compilation alone does not establish editorial acceptance.', '',
             '## Reproduction', '', 'From the experiment root, after preparing the candidate runtime:', '',
             '```sh', 'python3 qa/check_color_invariance.py', 'python3 qa/check_main_flow.py',
             'python3 qa/suites/run_unit_suites.py',
             'python3 qa/compat/run_compat.py', 'python3 qa/compat/validate_compat.py',
             'python3 qa/compat/audit_build_logs.py',
             'python3 qa/probes/run_editorial_probes.py', 'python3 qa/probes/validate_probe_pairs.py',
             'python3 qa/create_summary.py', '```', '']
    (QA / 'QA_SUMMARY.md').write_text('\n'.join(rows))
    print(report['status'].upper())
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
