#!/usr/bin/env python3
"""Check frozen v1.0.10 palette evidence against both independent candidates."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    original = json.loads((ROOT / 'qa/baseline/color-map.json').read_text())
    baseline = json.loads((ROOT / 'reports/SOURCE_BASELINE.json').read_text())
    reports = []
    for design in ('REFINED', 'MINIMAL'):
        source = ROOT / design / 'source/config'
        current = json.loads((source / 'color-map.json').read_text())
        normalized = json.loads(json.dumps(current))
        normalized['version'] = original['version']
        normalized['visual_rules']['AttentionBox'].pop('decoration', None)
        checks = {
            'frozen_color_map_matches_initial_v1_0_10_sha256': digest(ROOT / 'qa/baseline/color-map.json') ==
                baseline['protected_files']['/workspace/tex/config/color-map.json'],
            'candidate_version_is_1_0_11': current['version'] == '1.0.11',
            'new_attention_metadata_describes_only_geometry': current['visual_rules']['AttentionBox'].get('decoration') == 'accent-rule',
            'color_map_changes_only_version_and_attention_geometry': normalized == original,
            'semantic_roles_identical': current['semantic'] == original['semantic'],
            'ink_definitions_and_tints_identical': current['colors'] == original['colors'],
            'spot_name_identical': current['spot_ink_name'] == original['spot_ink_name'],
            'spot_alternate_cmyk_identical': current['spot_alternate_cmyk'] == original['spot_alternate_cmyk'],
            'approved_tints_identical': current['approved_tints_pending_press'] == original['approved_tints_pending_press'],
            'screen_base_identical': current['screen_base_hex'] == original['screen_base_hex'],
        }
        file_reports = {}
        for name in ('color-roles.tex', 'palette-screen.tex', 'palette-print2-spot.tex'):
            frozen = ROOT / 'qa/baseline' / name
            stored_hash = baseline['protected_files']['/workspace/tex/config/' + name]
            file_reports[name] = {
                'sha256': digest(source / name), 'baseline_sha256': stored_hash,
                'identical_to_captured_approved_v1_0_10': digest(frozen) == stored_hash == digest(source / name)}
        passed = all(checks.values()) and all(x['identical_to_captured_approved_v1_0_10'] for x in file_reports.values())
        reports.append({'design': design, 'status': 'passed' if passed else 'failed',
                        'checks': checks, 'files': file_reports})
    report = {'status': 'passed' if all(x['status'] == 'passed' for x in reports) else 'failed',
              'baseline': 'Frozen config bytes captured from approved v1.0.10, authenticated by SOURCE_BASELINE.json',
              'candidates': reports}
    (ROOT / 'qa/COLOR_INVARIANCE.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(report['status'].upper() + ': exact palette and semantic-role invariance for both candidates')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
