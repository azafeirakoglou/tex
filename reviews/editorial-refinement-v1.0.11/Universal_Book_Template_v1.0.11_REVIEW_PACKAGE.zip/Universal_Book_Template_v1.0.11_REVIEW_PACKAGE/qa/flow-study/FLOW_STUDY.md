# v1.0.11 editorial flow study

This study uses isolated copies of the two candidate source trees. The stable sources, review sources, real chapter content, and candidate source trees were not modified. The production change is `working-base/styles/book-editorial-flow.tex`, which must be input immediately before the final `\endinput` in `universalbook.sty`.

Two successful SCREEN trials were made for each design, with XeLaTeX through latexmk. Setup-only failed invocations lacked output subdirectories for LaTeX `\include` aux files; these were corrected before measurement. Final trial 2 used 5pt `intextsep` rather than trial 1's 8pt.

## Explicit parameter changes

All final values are centralized at the top of `book-editorial-flow.tex` and can be overridden through their named commands before that file is input.

| Parameter | Previous | Final | Scope |
|---|---|---|---|
| `\intextsep` | 12pt plus 2pt minus 2pt | 5pt plus 2pt minus 2pt | Figures/tables between text |
| `\textfloatsep` | 20pt plus 2pt minus 4pt | 12pt plus 2pt minus 3pt | Top/bottom floats |
| `\floatsep` | 12pt plus 2pt minus 2pt | 8pt plus 2pt minus 2pt | Adjacent floats |
| Quote before/after skip | 10pt / 10pt | 6pt / 6pt | `\BookQuote` |
| Quote space reservation | Five body baselines | Measured minipage height plus before skip | `\BookQuote` |
| Worked-example before/after skip | `\medskip` / `\medskip` | 3pt / 3pt | `workedexample` |
| Box before/after skip | 7pt / 8pt | 4pt / 5pt | ProblemBox/callouts within `workedexample` only |
| Above/below display skip | 11pt plus 3pt minus 6pt | 7pt plus 2pt minus 2pt | `workedexample` only |
| Short-display above skip | 0pt plus 3pt | 0pt plus 2pt | `workedexample` only |
| Short-display below skip | 6.5pt plus 3.5pt minus 3pt | 5pt plus 2pt minus 2pt | `workedexample` only |
| Solution label flow | Break permitted after label | Four-baseline reservation; no break immediately after label | `\SolutionHeading` |

There are no font size, font family, math scale, geometry, margin, palette, chapter-content, internal box padding, or caption-size changes in this flow override. No negative space or author page-break bypass is used. `ThinkBox` retains 3.2mm REFINED and 3.6mm MINIMAL top/bottom padding.

## Results

| Design | Final SCREEN pages | Overfull | Underfull | Warnings | Missing characters |
|---|---:|---:|---:|---:|---:|
| REFINED | 20 | 0 | 0 | 0 | 0 |
| MINIMAL | 20 | 0 | 0 | 0 | 0 |

The quote, attribution, and source now remain with the preceding history box on PDF page 7. Both complete worked examples fit on PDF page 8, including the second example's solution label and fraction equation. Author `\clearpage` commands remain intact. The quote's source ends near y=619.0pt; the final example equation ends near y=619.9pt (REFINED) / 620.3pt (MINIMAL), within the body lower edge near y=623.6pt.

Rendered pages were visually inspected. Text, math, callout brackets, and page furniture do not overlap. The compact external gaps preserve clear separation between statement, strategy, and solution.

Final artifacts: `{REFINED,MINIMAL}/trial-2/flow.pdf`, `flow.log`, `result.json`; preview images `*-trial2-page7.png`, `*-trial2-page8.png`.
