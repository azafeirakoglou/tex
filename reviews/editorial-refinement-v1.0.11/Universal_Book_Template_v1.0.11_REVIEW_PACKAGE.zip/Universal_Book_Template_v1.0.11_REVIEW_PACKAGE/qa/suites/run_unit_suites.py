#!/usr/bin/env python3
"""Run the original unittest suite in each independent candidate."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util,json,subprocess,sys,time,re
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('candidate_driver',ROOT/'run_candidates.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
def run(design):
 src=d.source(design);log=ROOT/'qa/suites'/(design+'.unittest.log');start=time.monotonic()
 with log.open('w') as f:r=subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],cwd=src,env=d.environment(src),stdout=f,stderr=subprocess.STDOUT)
 data=log.read_text();count=re.search(r'Ran (\d+) tests?',data)
 row={'design':design,'exit_code':r.returncode,'tests_run':int(count.group(1)) if count else None,'skipped':len(re.findall(r"\.\.\. skipped ",data)),'elapsed_seconds':round(time.monotonic()-start,2),'log':str(log.relative_to(ROOT))};print(json.dumps(row),flush=True);return row
with ThreadPoolExecutor(max_workers=2) as p:rows=list(p.map(run,d.DESIGNS))
(ROOT/'qa/suites/RESULTS.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(any(r['exit_code'] for r in rows))
