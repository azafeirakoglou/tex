#!/usr/bin/env python3
"""Check the final book's thematic heading and following theorem in actual PDFs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

import fitz

ROOT = Path(__file__).resolve().parent.parent
PT_TO_BP = 72 / 72.27
BAND = 'Απόδειξη — υπόδειγμα'
THEOREM = 'Πρόσθεση ίσων ποσοτήτων'


def normalized(text):
    return re.sub(r'\s+', ' ', text).strip()


def inspect(path):
    row = {'pdf': str(path.relative_to(ROOT)),
           'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'status': 'failed'}
    try:
        with fitz.open(path) as pdf:
            row['pages'] = len(pdf)
            bands, theorems = [], []
            for index, page in enumerate(pdf):
                for block in page.get_text('dict')['blocks']:
                    for line in block.get('lines', []):
                        for span in line['spans']:
                            text = normalized(span['text'])
                            if text == BAND and span['font'] == 'NotoSerif-Medium' and abs(span['size'] / PT_TO_BP - 11.7) < .012:
                                bands.append((index + 1, span))
                            if text.startswith('Θεώρημα ') and text.endswith(THEOREM):
                                theorems.append((index + 1, span))
            assert len(bands) == len(theorems) == 1, 'Expected exactly one thematic heading and following theorem title'
            band_page, band = bands[0]
            theorem_page, theorem = theorems[0]
            assert band_page == theorem_page, 'The thematic heading is orphaned on the page before its theorem'
            assert theorem['bbox'][1] > band['bbox'][3], 'The theorem must follow the thematic heading without overlap'
            row.update(status='passed', thematic_heading_page=band_page, theorem_page=theorem_page,
                       heading_size_tex_pt=round(band['size'] / PT_TO_BP, 4),
                       heading_bbox=list(band['bbox']), theorem_bbox=list(theorem['bbox']),
                       vertical_gap_bp=round(theorem['bbox'][1] - band['bbox'][3], 4))
    except (AssertionError, RuntimeError, ValueError) as exc:
        row['error'] = str(exc)
    return row


def main():
    rows = [inspect(ROOT / 'pdf' / f'v1.0.11_{design}_{edition}.pdf')
            for design in ('REFINED', 'MINIMAL') for edition in ('PRINT', 'SCREEN')]
    report = {'status': 'passed' if all(row['status'] == 'passed' for row in rows) else 'failed',
              'scope': 'Actual-PDF regression: the thematic proof heading shares a page with the following theorem title.',
              'pdfs': rows}
    (ROOT / 'qa/MAIN_FLOW.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
