# Editorial geometry probe

These original QA sources exercise the public authoring API. They are additional
fixtures, not replacement book content. Regenerate them with
`python3 qa/probes/generate_editorial_probe.py`.

Compile the SCREEN/PRINT entrypoint from the relevant candidate source root,
adding this directory to `TEXINPUTS` and using the shared prepared runtime. The
candidate's own `config/editorial-design.tex` selects REFINED or MINIMAL. Keep all
output trees and auxiliary files under `runtime/tmp`.
The runner copies the final compact QA PDFs to `qa/probes/pdf/` and complete
XeLaTeX logs to `qa/probes/results/` for review without retaining auxiliary trees.

The probe deliberately includes:

- A long photo opening followed immediately by a paragraph (`PARAGRAPHSTART`),
  a long non-photo opening followed by `section` (`SECTIONSTART`), and a non-photo
  opening followed by `AttentionBox` (`CALLOUTSTART`). Corresponding `...NEXT`
  markers begin later pages to verify the body title occurs once.
- `THINKSHORTBEGIN/END` and `THINKMATHBEGIN/END`, plus dense inline and display
  mathematics, Greek/Latin variables, fractions, roots, indices, limits, sums,
  integrals, upright units and a chemical formula.
- Three long callouts, each containing exactly 36 paragraphs marked
  `PROBETHINKROW001`–`036`, `PROBEATTENTIONROW001`–`036`, and
  `PROBEHISTORYROW001`–`036`; `PROBE...BEGIN/END` delimit occupied fragments.
- A vector physics diagram with math labels and ticks, a figure caption between
  `FIGCAPBEGIN/END`, and a table caption between `TABLECAPBEGIN/END`.
- A 120-row long table (`PROBETABLEROW001`–`120`) whose repeated header contains
  `PROBETABLEHEAD`. Its multiline caption is marked `LONGCAPBEGIN/END` and remains
  on the first table page. This tests captions of multipage tables, not a caption
  whose own text spans physical pages.
- Real figure/table labels and references (`CAPTIONREFS`, `LONGTABLEREF`), followed
  by `AFTERLONGTABLEBLACK` to detect leaked table color state.

The final marker is `EDITORIALPROBEEND`.

`typography-metrics.tex` is a controlled real-PDF measurement fixture. Compile once
per design/edition, adding `\def\MetricsPrint{1}` before input for PRINT. It
measures the requested font roles, actual STIX math sizes in body/callouts and
diagram labels/ticks, worked example titles, and the preserved History title.
It also measures the retained 11.7 pt thematic heading, 8 pt headers/footers,
and both figure and table captions.

Run the complete probe set from the experiment root:

```sh
python3 qa/probes/run_editorial_probes.py
python3 qa/probes/validate_probe_pairs.py
```

`check_editorial_pdf.py` checks actual fonts and sizes, exact paragraph/row
preservation, one body title per chapter, first-fragment icons, repeated table
heads, resolved references, caption hanging alignment and unchanged SCREEN
BookSecondary (`8493A9`). The paired validator independently checks PRINT spot
tints against the same unchanged colour map, all five plates, embedded fonts,
170 × 240 mm page size and exact PRINT/SCREEN text positions.

The fixture's table columns total 116 mm; its first 38 mm column accommodates
the deliberately long monospace row markers. The diagram's fraction label sits
above the rising data line. These diagnostic-layout choices concern original
QA content and do not change any existing book diagram or physics information.
