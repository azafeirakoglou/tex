#!/usr/bin/env python3
"""Rerun final main PRINT/SCREEN validation within the independent package."""
from pathlib import Path
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('candidate_driver', ROOT / 'run_candidates.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)


def main():
    directory = ROOT / 'qa/main'
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for design in driver.DESIGNS:
        source = driver.source(design)
        report = directory / (design + '.json')
        log = directory / (design + '.log')
        command = [sys.executable, 'scripts/validate_pdf.py',
                   '--print', str(ROOT / 'pdf' / f'v1.0.11_{design}_PRINT.pdf'),
                   '--screen', str(ROOT / 'pdf' / f'v1.0.11_{design}_SCREEN.pdf'),
                   '--map', str(source / 'config/color-map.json'),
                   '--report', str(report)]
        with log.open('w') as stream:
            result = subprocess.run(command, cwd=source, env=driver.environment(source),
                                    stdout=stream, stderr=subprocess.STDOUT)
        rows.append({'design': design, 'exit_code': result.returncode,
                     'report': str(report.relative_to(ROOT)), 'log': str(log.relative_to(ROOT))})
        print(design, 'PASS' if result.returncode == 0 else 'FAIL', flush=True)
    (directory / 'RESULTS.json').write_text(json.dumps(rows, indent=2) + '\n')
    return int(any(row['exit_code'] for row in rows))


if __name__ == '__main__':
    raise SystemExit(main())
