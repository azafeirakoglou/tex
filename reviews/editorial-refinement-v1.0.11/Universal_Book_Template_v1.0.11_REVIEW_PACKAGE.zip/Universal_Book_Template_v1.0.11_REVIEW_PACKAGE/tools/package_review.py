#!/usr/bin/env python3
"""Create the review ZIP from explicit final artifacts; never publish or release."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
NAME = 'Universal_Book_Template_v1.0.11_REVIEW_PACKAGE'
ROOT_FILES = [
    'README.md', 'REQUEST.md', 'REPRODUCTION.md', 'ADOPTION_GUIDE.md',
    'EDITORIAL_REFINEMENT_REPORT.md', 'CHANGELOG_v1.0.11.md',
    'TECHNICAL_REPORT.md', 'CANDIDATE_MANIFEST.json', 'BUILD_RESULTS.json',
    'run_candidates.py', 'prepare_runtime.py', 'requirements-review.txt',
]
SKIP_PARTS = {'.local', 'build', '__pycache__', '.git', '.pytest_cache', '.venv'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def candidates():
    result = set()
    for name in ROOT_FILES:
        path = ROOT / name
        if path.is_file():
            result.add(path)
    trees = ['REFINED/source', 'MINIMAL/source', 'pdf', 'runtime/fonts',
             'runtime/licenses', 'runtime/texmf', 'tools', 'logs',
             'qa/baseline', 'qa/main', 'qa/compat', 'qa/probes',
             'visual-audit/final', 'visual-audit/final-probes']
    for folder in trees:
        for path in (ROOT / folder).rglob('*'):
            relative = path.relative_to(ROOT)
            # Keep the source-bound single-page probe renders. Side-by-side
            # copies duplicate those same pixels and add no independent proof.
            redundant_probe_pair = (folder == 'visual-audit/final-probes' and
                                    path.name.startswith('PAIR_'))
            if (path.is_file() and not path.is_symlink() and
                    not redundant_probe_pair and
                    not any(part in SKIP_PARTS for part in relative.parts) and
                    path.suffix not in ('.pyc', '.aux', '.out', '.toc', '.fls', '.fdb_latexmk', '.xdv') and
                    not any(word in path.name.lower() for word in ('initial-', 'pre-rule-extractor', 'recheck', 'pre_category'))):
                result.add(path)
    for path in (ROOT / 'reports').glob('*'):
        if (path.is_file() and 'draft' not in path.name.lower() and
                path.name not in ('PACKAGE_INTEGRITY.json', 'PACKAGE_SELECTION.txt')):
            result.add(path)
    for pattern in ('*.py', '*.json', 'QA_SUMMARY.md'):
        result.update(p for p in (ROOT / 'qa').glob(pattern) if p.is_file())
    for name in ('run_unit_suites.py', 'RESULTS.json', 'REFINED.unittest.log', 'MINIMAL.unittest.log'):
        path = ROOT / 'qa/suites' / name
        if path.is_file():
            result.add(path)
    for name in ('FLOW_STUDY.md', 'FINAL_RESULTS.json'):
        path = ROOT / 'qa/flow-study' / name
        if path.is_file():
            result.add(path)
    for path in (ROOT / 'proofs/openings').rglob('*'):
        relative = path.relative_to(ROOT / 'proofs/openings')
        if (path.is_file() and 'deferred-draft' not in relative.parts and
                (path.suffix in ('.py', '.tex', '.json', '.md', '.pdf', '.log', '.stdout', '.png') or
                 ('extra-edges' in relative.parts and path.suffix == '.fls'))):
            result.add(path)
    for name in ('RUNTIME_MANIFEST.json',):
        result.add(ROOT / 'runtime' / name)
    for name in ('README.md', 'VISUAL_EVIDENCE.json'):
        path = ROOT / 'visual-audit' / name
        if path.is_file():
            result.add(path)
    return sorted(result, key=lambda path: str(path.relative_to(ROOT)))


def make(output, listing_only=False):
    selected = candidates()
    if listing_only:
        print('\n'.join(str(path.relative_to(ROOT)) for path in selected))
        print(f'{len(selected)} files; {sum(path.stat().st_size for path in selected):,} uncompressed bytes')
        return
    essential = ROOT_FILES + ['pdf/' + name for name in (
        'v1.0.11_REFINED_PRINT.pdf', 'v1.0.11_REFINED_SCREEN.pdf',
        'v1.0.11_MINIMAL_PRINT.pdf', 'v1.0.11_MINIMAL_SCREEN.pdf',
        'EDITORIAL_REFINEMENT_COMPARISON.pdf')]
    missing = [name for name in essential if ROOT / name not in selected]
    if missing:
        raise RuntimeError('Incomplete final package; missing: ' + ', '.join(missing))
    hashes = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for path in selected}
    contents = json.dumps({'status': 'independent_review_candidates_not_stable',
                           'files_sha256': hashes}, ensure_ascii=False, indent=2).encode() + b'\n'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        entries = [(name, (ROOT / name).read_bytes()) for name in hashes]
        entries.append(('PACKAGE_CONTENTS.json', contents))
        for name, data in entries:
            info = zipfile.ZipInfo(NAME + '/' + name, date_time=(2026, 11, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise RuntimeError('ZIP CRC failure')
        for name, expected in hashes.items():
            if sha(archive.read(NAME + '/' + name)) != expected:
                raise RuntimeError('Archived file hash mismatch: ' + name)
    report = {'status': 'passed', 'zip': str(output), 'sha256': sha(output.read_bytes()),
              'bytes': output.stat().st_size, 'archived_files': len(hashes) + 1,
              'crc_verified': True, 'all_archived_file_sha256_verified': True,
              'excluded': ['stable repository', 'working-base staging source', '.local', 'build',
                           'compiled TeX formats', 'runtime caches and temp trees', 'old render/trial evidence'],
              'internal_hash_manifest': NAME + '/PACKAGE_CONTENTS.json'}
    (ROOT / 'reports/PACKAGE_INTEGRITY.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / (NAME + '.zip'))
    parser.add_argument('--list', action='store_true', help='List selected files without writing an archive')
    args = parser.parse_args()
    make(args.output.resolve(), args.list)
