#!/usr/bin/env python3
"""Verify the captured original workspace without writing to its repository."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def main():
    baseline = json.loads((ROOT / 'reports/SOURCE_BASELINE.json').read_text())
    repo = Path(baseline['repository'])
    differences = []
    for filename, expected in baseline['protected_files'].items():
        path = Path(filename)
        if not path.is_file():
            differences.append({'path': filename, 'reason': 'missing'})
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            differences.append({'path': filename, 'reason': 'changed'})
    def git(*args):
        return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()
    actual = {'head': git('rev-parse', 'HEAD'),
              'branch': git('branch', '--show-current'),
              'git_status': git('status', '--porcelain')}
    checks = {key + '_unchanged': actual[key] == baseline[key]
              for key in ('head', 'branch', 'git_status')}
    checks['all_protected_files_unchanged'] = not differences
    report = {'status': 'passed' if all(checks.values()) else 'failed',
              'checked_at_utc': datetime.now(timezone.utc).isoformat(),
              'protected_file_count': len(baseline['protected_files']),
              'checks': checks, 'git': actual, 'differences': differences,
              'scope': 'Original stable tracked files and pre-existing stable/review PDFs and review ZIP; no repository writes.'}
    (ROOT / 'reports/STABLE_INTEGRITY.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(report['status'].upper(), report['protected_file_count'], 'protected files')
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
