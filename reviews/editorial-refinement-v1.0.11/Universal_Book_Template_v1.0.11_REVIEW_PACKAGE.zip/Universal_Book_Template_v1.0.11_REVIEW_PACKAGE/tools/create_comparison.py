#!/usr/bin/env python3
"""Copy corresponding A/B pages at exactly 1:1 scale, with no page overlays."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

import fitz

ROOT = Path(__file__).resolve().parent.parent
PT_PER_MM = 72 / 25.4


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(output):
    output.parent.mkdir(parents=True, exist_ok=True)
    document = fitz.open()
    labels, toc, rows, inputs = [], [], [], {}
    pairs = []
    for profile in ('SCREEN', 'PRINT'):
        sources = {design: ROOT / 'pdf' / f'v1.0.11_{design}_{profile}.pdf'
                   for design in ('REFINED', 'MINIMAL')}
        opened = {design: fitz.open(path) for design, path in sources.items()}
        counts = {len(pdf) for pdf in opened.values()}
        if len(counts) != 1:
            raise RuntimeError('Corresponding source page counts differ: ' + profile)
        toc.append([1, profile + ' — corresponding A/B pages at 1:1', len(document) + 1])
        for index in range(next(iter(counts))):
            toc.append([2, f'{profile} — source page {index + 1}', len(document) + 1])
            for letter, design in (('A', 'REFINED'), ('B', 'MINIMAL')):
                pdf = opened[design]
                rect = pdf[index].rect
                if (abs(rect.width - 170 * PT_PER_MM) > .02 or
                        abs(rect.height - 240 * PT_PER_MM) > .02):
                    raise RuntimeError('Unexpected physical page size: ' + str(sources[design]))
                target = len(document)
                document.insert_pdf(pdf, from_page=index, to_page=index, links=False)
                title = f'{profile} {letter} {design} — source page {index + 1}'
                toc.append([3, title, target + 1])
                labels.append({'startpage': target, 'prefix': title, 'style': ''})
                rows.append({'comparison_page': target + 1, 'profile': profile,
                             'design': design, 'source_page': index + 1,
                             'page_mm': [rect.width / PT_PER_MM, rect.height / PT_PER_MM],
                             'scale': 1, 'page_content_overlay': False})
                pairs.append((sources[design], index, target))
        for design, pdf in opened.items():
            inputs[str(sources[design].relative_to(ROOT))] = sha(sources[design])
            pdf.close()
    document.set_toc(toc)
    document.set_page_labels(labels)
    document.set_metadata({'title': 'Universal Book Template v1.0.11 — Editorial Refinement A/B Comparison',
                           'subject': 'Review candidates; 170 × 240 mm, unchanged source pages copied 1:1. SCREEN then PRINT, alternating A/B. Not a press master.',
                           'author': 'Universal Book Template',
                           'keywords': 'review, candidate, REFINED, MINIMAL, 1:1'})
    document.save(output, garbage=4, deflate=True)
    document.close()
    # Check actual rendered pixels, rather than trusting a nominal scale setting.
    with fitz.open(output) as comparison:
        for path, source_page, target_page in pairs:
            with fitz.open(path) as original:
                source_pix = original[source_page].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
                target_pix = comparison[target_page].get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
                if (source_pix.width, source_pix.height, source_pix.samples) != (
                        target_pix.width, target_pix.height, target_pix.samples):
                    raise RuntimeError(f'Render differs: comparison page {target_page + 1}')
    report = {'status': 'passed', 'pdf': str(output.relative_to(ROOT)),
              'sha256': sha(output), 'pages': len(rows), 'inputs_sha256': inputs,
              'method': 'Direct page insertion, no overlays, no scaling. All pages pixel-identical to source at 72 dpi. Links omitted; bookmarks and page labels identify candidates.',
              'page_map': rows}
    destination = ROOT / 'reports/COMPARISON_INTEGRITY.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(f'Created {len(rows)} comparison pages at 1:1; all renders match source pages.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'pdf/EDITORIAL_REFINEMENT_COMPARISON.pdf')
    args = parser.parse_args()
    build(args.output.resolve())
