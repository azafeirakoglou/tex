# Visual audit workspace

The authoritative final views are in `final/` (four 20-page books) and
`final-probes/` (typography metrics and 43-page edge fixtures). Their current
PDF SHA-256 values, exact pages actually viewed and PNG hashes are bound in
`VISUAL_EVIDENCE.json`. Earlier top-level renders and the pre-category manifest
are historical working evidence and must not be mistaken for the final PDFs.

Only v1.0.11 review outputs are written here. The approved v1.0.10 PDFs are read only.

All whole-page review renders use the same 1.5× matrix (108 dpi) for every PDF with its native 170 × 240 mm page box. Detail crops, when used, record their page coordinates and matrix in their manifest. No page is independently fit to a content box. Render pixel sizes are evidence of a common scale; screen display itself is not a calibrated physical print.

The baseline map identifies actual content, not an assumed fixed page number for new candidates. Candidate page maps will be extracted afresh before corresponding subjects are compared.

PDF proof outputs and render manifests are evidence only; neither candidate is approved or merged by the visual review.
