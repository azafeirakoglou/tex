#!/usr/bin/env python3
"""Prepare the self-contained review runtime without downloads or stable writes."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['TMPDIR'] = str(ROOT / 'runtime/tmp')


def prepare_relative_links():
    # Recreate only symlinks: moving an unpacked, previously prepared review
    # must not continue reading fonts or writing formats through its old path.
    for design in ('REFINED', 'MINIMAL'):
        source = ROOT / design / 'source'
        if not source.is_dir():
            raise RuntimeError('Independent candidate source missing: ' + str(source))
        local = source / '.local'
        local.mkdir(exist_ok=True)
        for folder in ('fonts', 'texmf', 'texmf-var'):
            link = local / folder
            if link.is_symlink():
                link.unlink()
            if not link.exists():
                relative = os.path.relpath(ROOT / 'runtime' / folder, start=local)
                link.symlink_to(relative, target_is_directory=True)


def main():
    required = ['fc-cache', 'kpsewhich', 'fmtutil-user', 'xetex', 'xelatex', 'latexmk']
    missing = [tool for tool in required if not shutil.which(tool)]
    if missing:
        raise RuntimeError('Missing system tools: ' + ', '.join(missing) + '; see REPRODUCTION.md')
    manifest = json.loads((ROOT / 'runtime/RUNTIME_MANIFEST.json').read_text())
    for name, expected in manifest['sha256'].items():
        path = ROOT / name
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise RuntimeError('Bundled runtime dependency missing or altered: ' + name)
    prepare_relative_links()
    from run_candidates import prepare, environment, source
    prepare()
    log = ROOT / 'runtime/format-setup.log'
    with log.open('w') as stream:
        result = subprocess.run(['fmtutil-user', '--byfmt', 'xelatex', '--quiet'],
                                env=environment(source('REFINED')),
                                stdout=stream, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError('Local Greek XeLaTeX format failed; see ' + str(log))
    fmt = ROOT / 'runtime/texmf-var/web2c/xetex/xelatex.fmt'
    if not fmt.is_file():
        raise RuntimeError('fmtutil did not create ' + str(fmt))
    print('Prepared both independent candidates using bundled verified fonts and Greek patterns.')
    print('Next: python3 run_candidates.py --jobs 2')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('Review setup failed: ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
